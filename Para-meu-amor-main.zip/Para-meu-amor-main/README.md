Para Meu Amor

Esse site foi feito com muito carinho (e um toque de loucura romântica) pra alguém muito especial.

O que tem aqui?

Emojis 😻 caindo sem parar porque o amor é exagerado mesmo.

Um carrossel com fotos megas fofas

Um contador mostrando exatamente há quanto tempo a gente tá nessa jornada juntos (desde 26/06/2024).

Uma mensagem cheia de sentimento, direto do coração.

E claro, a trilha sonora perfeita: "Aliança" dos Tribalistas, tocando automático pra entrar no clima.


Tudo isso com um visual bonitão e feito com muito amor (e várias madrugadas de código).


---
